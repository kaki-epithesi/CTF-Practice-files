class cipher(object):
	limit = 128
	keys = (7, 3, 55)

	def __init__(self):
		pass

	def enc_char(self,ch):
		k1, k2, ki = self.keys
		return (chr((k1 * ord(ch) + k2) % self.limit))

	def enc(self,s):
		return "".join(map(self.enc_char, s))

	def dec_char(self,ch):
		pass

	def dec(self,s):
		pass

noob = cipher()
f = open('flag.txt', 'rb')
s = f.readline().decode()[:-1]
print(noob.enc(s))
f = open('out.txt', 'rb')
s = f.readline().decode()[:-1]
flag = noob.dec(s)
print("noob-atbash{",end='')
print(flag,end='')
print("}")
