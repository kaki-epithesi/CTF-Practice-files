#!/usr/bin/env python3
# -*- coding : utf-8 -*-

def random(i,j):
    return(i << j)

def think(a,b):
    if b == 0:
        return -1*a
    import pwn
    r = pwn.process('./think')
    r.sendline(str(a))
    c = int(r.recv().decode())
    return c*b
