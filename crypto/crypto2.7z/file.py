#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from Crypto.Util.number import bytes_to_long
import pwning

f1 = open('flag.txt', 'rb')
f2 = open('key.txt', 'rb')

password = 'hiding_in_planes'

flag = f1.readline()[:-1]
key = f2.readline()[:-1]

flag_long = bytes_to_long(flag)
key_long = bytes_to_long(key)
password_long = bytes_to_long(bytes(password,'utf-8'))

hint1 = pwning.random(password_long,4)

for i in str(hint1):
    if(int(i) % 2 == 0):
        key_long ^= 10
    else:
        key_long ^= 21

l3 = []
k = str(key_long)
k2 = str(key_long)

str_hint1 = str(hint1)[:-1]

for i in range(0,39):
    l3.append(int(str_hint1[i])^int(k[i]))

print("l3 = ",l3)

s = str(flag_long)
l = []

for i in range(0,len(s),2):
    l.append(pwning.think(int(s[i]),int(s[i+1])))

l1 = []
for i in range(0,len(l)):
    l1.append(l[i]^int(k[i]))

print("l1 = ", l1)
